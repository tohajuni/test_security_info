int main () {
printout;
}
